"""Offline synthetic before/after comparison; creates new artifacts only."""
from dataclasses import asdict
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import core

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PRODUCTION = ROOT/'src/limo_maze_mission/limo_maze_mission'
spec = importlib.util.spec_from_file_location('production_association_baseline', PRODUCTION/'core.py')
baseline = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = baseline
spec.loader.exec_module(baseline)


def detection(y):
    return {'class_id': 'red_object', 'position': [1., y, .1], 'confidence': .95}


def run(reverse=False, use_batch=True):
    store = core.TargetStore() if use_batch else baseline.TargetStore()
    trace = []
    for stamp in (1, 2, 3):
        items = [detection(-.09), detection(.09)]
        if reverse:
            items.reverse()
        if use_batch:
            result = store.add_frame(items, stamp*1_000_000_000, source='synthetic',
                                    sensor_frame='camera', epoch='synthetic-map')
        else:
            result = {'assigned_uids': [store.add(item['class_id'], item['position'], stamp,
                item['confidence']).uid for item in items]}
        trace.append({'stamp_ns': stamp*1_000_000_000, 'observations': items,
                      'association': result, 'tracks_after_frame': [asdict(t) for t in store.targets]})
    return {'reverse_input': reverse, 'batch': use_batch, 'trace': trace,
            'confirmed_tracks': [asdict(t) for t in store.confirmed()]}


def main():
    report = {'schema_version': 1, 'scope': 'Synthetic observation batches, no rendered data, truth input or ROS runtime',
        'production_modified': False, 'physical_object_identity_proven': False,
        'source_sha256': {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in [PRODUCTION/'core.py', PRODUCTION/'node.py', HERE/'core.py', HERE/'node.py',
                         HERE/'test_association.py', HERE/'replay.py']},
        'cases': [run(False, False), run(True, False), run(False, True), run(True, True)]}
    counts = [len(case['confirmed_tracks']) for case in report['cases']]
    assert counts == [1, 1, 2, 2]
    assert report['cases'][2]['confirmed_tracks'] == report['cases'][3]['confirmed_tracks']
    with (HERE/'replay-result-v2.json').open('x') as output:
        json.dump(report, output, indent=2, allow_nan=False)
        output.write('\n')
    with (HERE/'candidate-v2.patch').open('x') as output:
        for name in ('core.py', 'node.py'):
            output.writelines(difflib.unified_diff((PRODUCTION/name).read_text().splitlines(True),
                (HERE/name).read_text().splitlines(True),
                fromfile='a/src/limo_maze_mission/limo_maze_mission/'+name,
                tofile='b/src/limo_maze_mission/limo_maze_mission/'+name))
    print(json.dumps({'confirmed_counts_before_after': counts, 'output': str(HERE/'replay-result-v2.json')}))


if __name__ == '__main__':
    main()
