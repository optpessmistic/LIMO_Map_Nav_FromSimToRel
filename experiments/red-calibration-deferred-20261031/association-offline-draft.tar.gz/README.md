# 同帧一对一目标关联候选补丁

独立草稿，生产未修改，未启动 ROS/Gazebo。`core.py` 和 `node.py` 是生产副本中的接入候选；**`candidate-v2.patch` 是最终差异**。`test_association.py` 使用合成点和 AST 提取的真实适配器方法，不依赖 ROS。`replay-result-v2.json` 保存最终版本 0.18 m 两观测的逐帧对照及源码哈希。无后缀的旧 patch/result 保留为首次离线版本，后续整合应使用 v2。

## 修复对象

原 `on_observations` 逐项调用 `TargetStore.add`。0.18 m 相邻观测都落入 0.30 m 匹配半径；第二项选中第一项刚建立或更新的 track，却因相同 stamp 不增加命中数。连续三帧只确认一条记录，而且交换输入顺序会改变被保留的位置。

新 `add_frame(observations, stamp_ns, source=..., sensor_frame=..., epoch=...)` 一次接收一个完整采集帧。先冻结旧 track 列表进行一对一指派，再统一提交所有更新和新 track。新 track 不参与本帧剩余项的匹配。0.18 m 两检测三帧得到两条确认记录，正反输入顺序结果一致；半径仍为 0.30 m。

## 确定性、有界算法

观测先按 class、instance_id、XYZ、confidence 规范排序；旧 track 按 UID 排序。兼容边必须同 class、instance_id 不冲突且 XY 距离不超过原半径。兼容边成本是 `(distance / radius)^2`，每条不超过 1；每个未匹配 dummy 成本为 `n+1`。因此矩形 Hungarian 求解先最大化兼容旧 track 匹配数量，再最小化平方 XY 位移。每条旧记录最多被一个观测匹配，空余观测分别建新记录。等成本按规范输入和最小列顺序处理。

这避免简单全局最近贪心的陷阱：旧记录位于 0 和 0.3 m，观测位于 -0.2 和 0.15 m；0.15 m 若抢先占用 0，会让仅能匹配 0 的 -0.2 m 新建冗余记录。候选算法保留两条兼容旧匹配。

上限为每帧 100 观测、256 条记录、16 个 `(source, sensor_frame)` 流，复杂度 `O(n²m)`，最大矩阵 100×356。达到容量时整帧拒绝，旧状态不变，不逐出已确认记录。这些是资源容量，不是已知目标数量或目标位置先验。数值输入必须有限，XYZ 绝对值上限 1,000,000 m；这些宽数值界限防止溢出，也不是迷宫几何真值。

## 保留与收紧的语义

- 原 min_hits、min_confidence、0.30 m gate、命中次数最多取 10 的均值权重保持。
- 原所谓“过期”是未确认记录的确认窗口：新观测距离 first_stamp 超过 window 就重置命中计数。原代码没有按时间删除 track；候选也不新增删除，已确认记录仍保留。
- 原 `add` 兼容接口保持，供现有单观测调用与测试使用；正式多目标路径必须一次调用 `add_frame`，不能混用逐项调用来表达一帧。`add` 本身不获得新批量资源/epoch 水位保护。
- 同流 stamp_ns 水位禁止重放和乱序帧增加或新建记录。相同戳与相同规范内容是 duplicate；相同戳不同内容是 conflicting_duplicate；均不改变状态。跨流同戳匹配仍受原 track.last_stamp 检查，不重复增加命中。
- 帧重复键保留整数纳秒；Target 的 first/last_stamp 仍为原 float 秒字段，极大时间下精度折叠会保守地少计命中，而不会额外确认。原 v1 浮点 stamp 无法恢复已丢失精度；node 优先严格解析 sec/nanosec 格式。
- 整个 target batch 完成验证与容量检查后才提交；坏的第二项不会先写入第一项。低置信但合法观测单独忽略；非法数字、结构或标识使整帧拒绝。
- 每个 store 在第一条合法观测帧（包括空帧）绑定当前消费端 map epoch；变化需要新 store/新任务，不能混合旧地图坐标。既有运行中 epoch 改变、clock reset、localization jump 阻断规则保留；**额外收紧** pre-home 已绑定 epoch 的变更，也要求新任务，防止启动前的旧坐标/水位混入新地图。这项收紧应在正式整合时明确审查。
- node 仅在 map_epoch_ready 和 coordinates_valid 时处理，并检查消息若声明 map_epoch 是否一致。**当前 producer 的 v1 target payload 没有 epoch/session 字段**，因此这只是消费端绑定，不能宣称已独立验证 producer epoch。未来应复用 FrameEvidence 的 epoch/session/sequence 形成明确来源合同。

## 身份歧义

一帧中完全相同 class/instance/XYZ 的观测（即使 confidence 不同），或重复同一非空 instance_id，无法当作独立物体证据，候选明确拒绝该帧。不同 instance_id 可在同一位置形成独立候选，但仍需各自时间确认。

距离不同的两个 blob 也可能是同一个物体被重复分割。本改动保证几何观测不会在同帧争用同一条记录，**不证明两个 blob 就是两个物体**。完全重叠、遮挡、身份交叉、重定位漂移、同类物体间距接近误差尺度时，单纯 XYZ 无法可靠确定身份；最大兼容匹配也可能把新物体接到一个旧记录上。重复分割若持续多帧，仍可能产生多条确认记录。应由物品定义、实例特征/合法标签、bbox/分割证据与多视角关联解决，不能读取仿真真值或预设目标数来补齐。

记录是静态地图注记，缺帧不代表目标消失；已确认记录也没有移动目标跟踪或 pose-graph landmark 重锚能力。正式整合前应审查这些边界，并先在新输出目录验证相邻渲染场景的 detector component 数和 association 数，保持原失败证据不变。

## 已有离线验证

最终 **28 项测试通过，0.246 s**；具体结果见 `offline-tests-result.json`。包括正反顺序、两个近目标多帧、新近目标出现、单目标抖动、最优匹配贪心陷阱、确认窗口、重复/乱序/同戳冲突、多类别/实例 ID、低置信、非法值、容量边界、epoch、AST node 接入及旧最小 startup adapter 兼容。Hungarian 结果另与固定随机种子的 60 个小型矩阵穷举最优解比较。没有在线测试、识别准确率或物体数量正确性的声明。
