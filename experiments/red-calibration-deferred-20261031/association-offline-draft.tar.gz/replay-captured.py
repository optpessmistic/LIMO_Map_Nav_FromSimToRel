#!/usr/bin/env python3
"""Replay fixed-six saved observations only after case closure. No ROS/truth input.

The saved detector output is not recomputed or scored. Exact acquisition-time
odom<-camera TF maps its optical points into one reference frame. Comparing
association policies does not establish physical identity or detector accuracy.
"""
import argparse
from dataclasses import asdict
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASELINE = ROOT/'src/limo_maze_mission/limo_maze_mission/core.py'
CANDIDATE = HERE/'core.py'
EXPECTED_BASELINE = '4815a0d5725101c3f952c84ab540778e7341baf827678890a0bb66129401e113'
EXPECTED_CANDIDATE = '6e56ed052df3c08da6d413de3f8a455fbcf4f683706f3ee1ebcb5b0f2a30ac8e'
PAIRS = 6


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fail(condition, reason):
    if not condition:
        raise ValueError(reason)


def safe_child(root, relative):
    part = Path(relative)
    fail(not part.is_absolute() and '..' not in part.parts and '\\' not in relative, 'unsafe_evidence_path')
    path = (root/part).resolve()
    fail(path.is_relative_to(root.resolve()), 'evidence_path_escaped_root')
    return path


class Reader:
    def __init__(self, wall_seconds=30.):
        self.deadline = time.monotonic()+wall_seconds
        self.files, self.total = {}, 0

    def read(self, path, limit=8*1024**2, reference=None):
        fail(time.monotonic() < self.deadline, 'read_wall_deadline')
        path = Path(path).resolve()
        size = path.stat().st_size
        fail(path.is_file() and 0 <= size <= limit, 'evidence_file_limit')
        raw = path.read_bytes()
        fail(len(raw) == size and len(raw) <= limit, 'file_changed_while_reading')
        identity = {'bytes': len(raw), 'sha256': sha(raw)}
        key = str(path)
        if key in self.files:
            fail(self.files[key] == identity, 'input_changed_during_audit')
        else:
            self.total += len(raw)
            fail(self.total <= 128*1024**2, 'aggregate_input_limit')
        self.files[key] = identity
        if reference is not None:
            fail(isinstance(reference, dict) and identity == {k: reference.get(k) for k in identity},
                 'evidence_hash_or_size_mismatch:'+str(path))
        return raw

    def json(self, path, reference=None):
        def reject_constant(value):
            raise ValueError('nonfinite_json_token:'+value)
        def unique_pairs(pairs):
            result = {}
            for key, value in pairs:
                fail(key not in result, 'duplicate_json_key:'+key)
                result[key] = value
            return result
        result = json.loads(self.read(path, 2*1024**2, reference), parse_constant=reject_constant,
                            object_pairs_hook=unique_pairs)
        fail(isinstance(result, dict), 'json_object_required')
        return result

    def unchanged(self):
        for path, identity in list(self.files.items()):
            self.read(path, reference=identity)


def xyz(value, length):
    fail(isinstance(value, (list, tuple)) and len(value) == length and
         all(type(v) in (int, float) and math.isfinite(v) for v in value), 'finite_vector_required')
    return tuple(float(v) for v in value)


def rotate(q, p):
    x, y, z = p
    qx, qy, qz, qw = q
    tx, ty, tz = 2*(qy*z-qz*y), 2*(qz*x-qx*z), 2*(qx*y-qy*x)
    return x+qw*tx+qy*tz-qz*ty, y+qw*ty+qz*tx-qx*tz, z+qw*tz+qx*ty-qy*tx


def transform_point(transform, point, stamp_ns, optical):
    fail(isinstance(transform, dict), 'missing_reference_to_camera_tf')
    fail(transform.get('target_frame') == 'odom' and transform.get('source_frame') == optical,
         'tf_frame_mismatch')
    fail(type(transform.get('query_stamp_ns')) is int and transform['query_stamp_ns'] == stamp_ns and
         type(transform.get('returned_stamp_ns')) is int and transform['returned_stamp_ns'] == stamp_ns,
         'tf_not_exact_acquisition_stamp')
    t, q = xyz(transform.get('translation_xyz_m'), 3), xyz(transform.get('rotation_xyzw'), 4)
    fail(abs(sum(v*v for v in q)-1.) <= 1e-6, 'tf_quaternion_not_unit')
    rotated = rotate(q, xyz(point, 3))
    return [v+offset for v, offset in zip(rotated, t)]


def read_frames(case_dir, reader):
    case_dir = Path(case_dir).resolve()
    # First operation on the case is closure metadata, never sample scoring.
    closure = reader.json(safe_child(case_dir, 'result.json'))
    fail(closure.get('status') in ('captured', 'failed_or_incomplete') and
         closure.get('all_owned_groups_empty') is True, 'case_not_confirmed_closed')
    capture = safe_child(case_dir, 'capture')
    summary = reader.json(safe_child(capture, 'summary.json'))
    fail(summary.get('cleanup_complete') is True and summary.get('collection_complete') is True and
         summary.get('persistence_complete') is True and summary.get('source_unchanged') is True and
         summary.get('saved_pairs') == PAIRS and summary.get('requested_pairs') == PAIRS,
         'fixed_six_capture_not_complete')
    fail(summary.get('all_samples_valid') is True and not summary.get('selected_sample_conflicts') and
         not summary.get('errors'), 'capture_has_invalid_or_conflicting_samples')
    session = summary.get('capture_session')
    fail(isinstance(session, str) and 0 < len(session) <= 80, 'capture_session_invalid')
    checkpoint = reader.json(safe_child(capture, 'raw-checkpoint.json'), summary.get('raw_checkpoint'))
    fail(checkpoint.get('capture_session') == session, 'checkpoint_session_mismatch')
    committed = checkpoint.get('artifacts_saved_before_cleanup', {})
    fail('manifest.json' in committed, 'capture_manifest_missing_from_checkpoint')
    manifest = reader.json(safe_child(capture, 'manifest.json'), committed['manifest.json'])
    fail(manifest.get('capture_session') == session and manifest.get('case_id') == summary.get('case_id') and
         manifest.get('reference_frame') == 'odom', 'capture_manifest_identity_or_reference_mismatch')
    source_records = manifest.get('source', {}).get('sources', {})
    fail(isinstance(source_records, dict) and len(source_records) <= 16, 'source_provenance_count_limit')
    for original_path, identity in source_records.items():
        relative_source = 'source/'+Path(original_path).name
        fail(committed.get(relative_source) == identity, 'source_snapshot_manifest_mismatch')
        reader.read(safe_child(capture, relative_source), 2*1024**2, identity)
    entries = summary.get('samples')
    fail(isinstance(entries, list) and len(entries) == PAIRS, 'six_fixed_sample_entries_required')
    by_sequence = {item.get('sequence'): item for item in entries if isinstance(item, dict)}
    fail(set(by_sequence) == set(range(1, PAIRS+1)), 'selected_sequence_set_mismatch')
    frames, previous_stamp = [], -1
    for sequence in range(1, PAIRS+1):
        entry = by_sequence[sequence]
        relative = f'sample_{sequence:03d}/sample.json'
        fail(entry.get('artifact') == relative and entry.get('frame_valid') is True and
             entry.get('processing_status') == 'processed', 'fixed_sample_entry_invalid')
        fail(relative in committed, 'sample_missing_from_precleanup_checkpoint')
        sample = reader.json(safe_child(capture, relative), committed[relative])
        stamp = sample.get('stamp_ns')
        fail(sample.get('sequence') == sequence and sample.get('capture_session') == session and
             sample.get('frame_valid') is True and sample.get('processing_status') == 'processed' and
             not sample.get('reasons'), 'saved_sample_invalid')
        fail(type(stamp) is int and previous_stamp < stamp <= 2**63-1 and entry.get('stamp_ns') == stamp,
             'source_stamps_not_strictly_advancing')
        previous_stamp = stamp
        meta = sample.get('input_metadata', {})
        optical = sample.get('optical_frame')
        fail(isinstance(optical, str) and optical, 'missing_optical_frame')
        for kind in ('rgb', 'depth', 'rgb_info', 'depth_info'):
            item = meta.get(kind)
            fail(isinstance(item, dict) and item.get('stamp_ns') == stamp and item.get('frame_id') == optical,
                 'input_not_exact_stamp_and_frame:'+kind)
        for kind in ('rgb', 'depth'):
            relative_raw = f'sample_{sequence:03d}/{kind}.data'
            reference = sample.get('files', {}).get(kind+'.data')
            fail(isinstance(reference, dict) and committed.get(relative_raw) == reference,
                 'raw_image_manifest_reference_missing')
            raw = reader.read(safe_child(capture, relative_raw), reference=reference)
            fail(meta[kind].get('data_bytes') == len(raw) and meta[kind].get('data_sha256') == sha(raw),
                 'raw_image_and_processing_metadata_mismatch')
        detections = sample.get('detections')
        stats = sample.get('processing', {})
        fail(isinstance(detections, list) and len(detections) <= 100 and
             stats.get('detection_count') == len(detections) and
             type(stats.get('candidate_count')) is int and stats['candidate_count'] >= len(detections),
             'detection_counts_invalid')
        tf = sample.get('transforms', {}).get('reference_to_camera')
        # Validate exact TF even for an empty detector result.
        transform_point(tf, [0., 0., 0.], stamp, optical)
        observations = []
        for item in detections:
            fail(isinstance(item, dict) and isinstance(item.get('class_id'), str) and item['class_id'] and
                 type(item.get('confidence')) in (int, float) and math.isfinite(item['confidence']) and
                 0 <= item['confidence'] <= 1, 'invalid_saved_detection')
            observations.append({'class_id': item['class_id'],
                'position': transform_point(tf, item.get('position'), stamp, optical),
                'confidence': item['confidence'], 'instance_id': item.get('instance_id', '')})
        frames.append({'sequence': sequence, 'stamp_ns': stamp, 'reference_frame': 'odom',
            'sample_artifact': relative, 'sample_sha256': committed[relative]['sha256'],
            'candidate_count': stats['candidate_count'], 'detection_count': len(detections),
            'observations_in_reference': observations,
            'reference_to_camera_tf': tf})
    return frames, {'case_id': summary.get('case_id'), 'capture_session': session,
                    'status': closure['status'], 'all_owned_groups_empty': True,
                    'saved_detector_and_capture_source_sha256': source_records,
                    'coordinate_reference': 'odom; no map/world alignment or truth used'}


def load_core(path, expected, name, reader):
    raw = reader.read(path, 2*1024**2)
    fail(sha(raw) == expected, 'frozen_algorithm_source_changed:'+str(path))
    module = type(sys)(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def compare(frames, baseline, candidate, capture_session):
    comparisons = []
    for use_batch in (False, True):
        for reverse in (False, True):
            store = (candidate if use_batch else baseline).TargetStore()
            trace = []
            for frame in frames:
                observations = list(frame['observations_in_reference'])
                if reverse:
                    observations.reverse()
                if use_batch:
                    result = store.add_frame(observations, frame['stamp_ns'], source='saved_detector_output',
                        sensor_frame='saved_optical_stream', epoch='offline_capture:'+capture_session)
                else:
                    assigned = [store.add(item['class_id'], item['position'], frame['stamp_ns']/1e9,
                        item['confidence'], item.get('instance_id', '')) for item in observations]
                    result = {'assigned_uids': [None if target is None else target.uid for target in assigned]}
                trace.append({'sequence': frame['sequence'], 'stamp_ns': frame['stamp_ns'],
                    'candidate_count': frame['candidate_count'], 'detection_count': frame['detection_count'],
                    'association': result, 'track_count': len(store.targets),
                    'confirmed_track_count': len(store.confirmed()),
                    'tracks': [asdict(target) for target in store.targets]})
            comparisons.append({'algorithm': 'candidate_add_frame' if use_batch else 'original_add',
                'reverse_detection_order': reverse, 'frames': trace,
                'final_tracks': [asdict(target) for target in store.targets],
                'final_confirmed_tracks': [asdict(target) for target in store.confirmed()]})
    return comparisons


def audit(case_dir):
    reader = Reader()
    frames, closure = read_frames(case_dir, reader)
    baseline = load_core(BASELINE, EXPECTED_BASELINE, 'captured_baseline', reader)
    candidate = load_core(CANDIDATE, EXPECTED_CANDIDATE, 'captured_candidate', reader)
    comparisons = compare(frames, baseline, candidate, closure['capture_session'])
    reader.read(__file__, 2*1024**2)
    reader.unchanged()
    return {'schema_version': 1, 'input_validation_passed': True, 'read_only': True,
        'scope': 'Only association behavior of the original six saved detector outputs; no online experiment or accuracy scoring',
        'closure': closure, 'selected_frames': frames, 'comparisons': comparisons,
        'input_files': reader.files, 'input_bytes': reader.total,
        'physical_object_count_proven': False, 'recognition_accuracy_claimed': False,
        'world_or_target_truth_read': False,
        'limitations': ['Saved detections were not recomputed; this is an association replay.',
                       'Exact odom TF only; no simulator/world alignment or position error metric.',
                       'The offline_capture epoch is a local replay isolation key, not a measured map epoch.',
                       'No frame or observation was substituted, and no target-count prior was supplied.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    fail(not args.output.exists(), 'output_already_exists')
    report = audit(args.case_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as output:
        json.dump(report, output, indent=2, allow_nan=False)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps({'output': str(args.output), 'input_validation_passed': True,
        'confirmed_counts_original_forward_reverse_candidate_forward_reverse':
            [len(item['final_confirmed_tracks']) for item in report['comparisons']]}))


if __name__ == '__main__':
    main()
