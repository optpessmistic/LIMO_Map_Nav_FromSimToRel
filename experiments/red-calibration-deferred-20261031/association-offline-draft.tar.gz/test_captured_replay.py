"""Synthetic file-protocol tests only; never reads a real case directory."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('captured_replay_tested', HERE/'replay-captured.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)


class CapturedReplayTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='captured-synthetic-', dir=HERE)
        self.addCleanup(self.temp.cleanup)
        self.case = Path(self.temp.name)

    def write(self, path, value):
        raw = (json.dumps(value, allow_nan=False)+'\n').encode()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

    def fixture(self, *, closed=True, bad_tf=False, invalid_sample=None):
        self.write(self.case/'result.json', {'status': 'captured' if closed else 'running',
                                           'all_owned_groups_empty': closed})
        capture = self.case/'capture'
        entries, committed = [], {}
        capture.mkdir()
        (capture/'source').mkdir()
        source_raw = b'# synthetic source provenance; never executed\n'
        (capture/'source/fake.py').write_bytes(source_raw)
        source_identity = {'bytes': len(source_raw), 'sha256': replay.sha(source_raw)}
        committed['source/fake.py'] = source_identity
        committed['manifest.json'] = self.write(capture/'manifest.json', {
            'capture_session': 'synthetic', 'case_id': 'synthetic', 'reference_frame': 'odom',
            'source': {'sources': {'/synthetic/fake.py': source_identity}}})
        for sequence in range(1, 7):
            stamp = sequence*100_000_000+1_000_000_000
            directory = capture/f'sample_{sequence:03d}'
            directory.mkdir(parents=True)
            metadata, files = {}, {}
            for kind, raw in (('rgb', b'\x01\x02\x03'), ('depth', b'\x00\x00\x80\x3f')):
                (directory/(kind+'.data')).write_bytes(raw)
                reference = {'bytes': len(raw), 'sha256': replay.sha(raw)}
                files[kind+'.data'] = reference
                committed[f'sample_{sequence:03d}/{kind}.data'] = reference
                metadata[kind] = {'stamp_ns': stamp, 'frame_id': 'optical',
                                  'data_bytes': len(raw), 'data_sha256': replay.sha(raw)}
            for kind in ('rgb_info', 'depth_info'):
                metadata[kind] = {'stamp_ns': stamp, 'frame_id': 'optical'}
            tf = {'target_frame': 'odom', 'source_frame': 'optical',
                  'query_stamp_ns': stamp, 'returned_stamp_ns': stamp,
                  'translation_xyz_m': [0., 0., 0.], 'rotation_xyzw': [0., 0., 0., 1.]}
            if bad_tf and sequence == 2:
                tf['returned_stamp_ns'] += 1
            sample = {'sequence': sequence, 'capture_session': 'synthetic', 'stamp_ns': stamp,
                'frame_valid': sequence != invalid_sample, 'processing_status': 'processed', 'reasons': [],
                'input_metadata': metadata, 'optical_frame': 'optical', 'files': files,
                'detections': [{'class_id': 'red_object', 'confidence': .95, 'position': [1., y, .1]}
                               for y in (-.09, .09)],
                'processing': {'candidate_count': 2, 'detection_count': 2},
                'transforms': {'reference_to_camera': tf}}
            relative = f'sample_{sequence:03d}/sample.json'
            committed[relative] = self.write(capture/relative, sample)
            entries.append({'sequence': sequence, 'artifact': relative, 'frame_valid': True,
                            'processing_status': 'processed', 'stamp_ns': stamp})
        checkpoint = self.write(capture/'raw-checkpoint.json', {'capture_session': 'synthetic',
            'artifacts_saved_before_cleanup': committed})
        self.write(capture/'summary.json', {'case_id': 'synthetic', 'capture_session': 'synthetic',
            'cleanup_complete': True, 'collection_complete': True, 'persistence_complete': True,
            'source_unchanged': True, 'all_samples_valid': True, 'selected_sample_conflicts': [],
            'errors': [], 'saved_pairs': 6, 'requested_pairs': 6,
            'raw_checkpoint': {'artifact': 'raw-checkpoint.json', **checkpoint}, 'samples': entries})

    def test_rejects_unclosed_case_before_reading_samples(self):
        self.write(self.case/'result.json', {'status': 'running', 'all_owned_groups_empty': False})
        reader = replay.Reader()
        with self.assertRaisesRegex(ValueError, 'case_not_confirmed_closed'):
            replay.read_frames(self.case, reader)
        self.assertEqual(len(reader.files), 1)

    def test_synthetic_fixed_six_before_after_and_order_comparison(self):
        self.fixture()
        result = replay.audit(self.case)
        self.assertEqual([len(c['final_confirmed_tracks']) for c in result['comparisons']], [1, 1, 2, 2])
        self.assertEqual(result['comparisons'][2]['final_tracks'], result['comparisons'][3]['final_tracks'])
        self.assertEqual([f['sequence'] for f in result['selected_frames']], list(range(1, 7)))
        self.assertTrue(all(f['candidate_count'] == f['detection_count'] == 2 for f in result['selected_frames']))
        self.assertFalse(result['world_or_target_truth_read'])
        self.assertFalse(result['physical_object_count_proven'])

    def test_exact_tf_rotate_and_translate_into_common_odom(self):
        tf = {'target_frame': 'odom', 'source_frame': 'optical', 'query_stamp_ns': 123,
              'returned_stamp_ns': 123, 'translation_xyz_m': [2., 3., 4.],
              'rotation_xyzw': [0., 0., math.sqrt(.5), math.sqrt(.5)]}
        value = replay.transform_point(tf, [1., 0., 0.], 123, 'optical')
        for observed, expected in zip(value, (2., 4., 4.)):
            self.assertAlmostEqual(observed, expected)

    def test_one_nanosecond_tf_mismatch_rejects_instead_of_using_latest(self):
        self.fixture(bad_tf=True)
        with self.assertRaisesRegex(ValueError, 'tf_not_exact_acquisition_stamp'):
            replay.audit(self.case)

    def test_invalid_fixed_second_sample_not_replaced_by_later_sample(self):
        self.fixture(invalid_sample=2)
        with self.assertRaisesRegex(ValueError, 'saved_sample_invalid'):
            replay.audit(self.case)

    def test_altered_raw_bytes_and_sample_manifest_hash_are_detected(self):
        self.fixture()
        path = self.case/'capture/sample_002/rgb.data'
        path.write_bytes(b'\x03\x02\x01')
        with self.assertRaisesRegex(ValueError, 'hash_or_size_mismatch'):
            replay.audit(self.case)

    def test_mismatched_tf_frame_or_quaternion_rejects(self):
        tf = {'target_frame': 'world', 'source_frame': 'optical', 'query_stamp_ns': 123,
              'returned_stamp_ns': 123, 'translation_xyz_m': [0., 0., 0.], 'rotation_xyzw': [0., 0., 0., 1.]}
        with self.assertRaisesRegex(ValueError, 'tf_frame_mismatch'):
            replay.transform_point(tf, [1., 0., 0.], 123, 'optical')
        tf['target_frame'], tf['rotation_xyzw'] = 'odom', [0., 0., 0., 0.]
        with self.assertRaisesRegex(ValueError, 'quaternion_not_unit'):
            replay.transform_point(tf, [1., 0., 0.], 123, 'optical')

    def test_altered_saved_source_snapshot_is_detected_without_executing_it(self):
        self.fixture()
        (self.case/'capture/source/fake.py').write_bytes(b'raise RuntimeError("must never execute")\n')
        with self.assertRaisesRegex(ValueError, 'hash_or_size_mismatch'):
            replay.audit(self.case)


if __name__ == '__main__':
    unittest.main(verbosity=2)
