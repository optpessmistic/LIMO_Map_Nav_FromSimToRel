# Finite red calibration runner draft

Status: **not run against ROS/Gazebo**. This directory is ignored experimental code, not a production entry point. It does not start navigation, perception publishers, missions, action clients, velocity publishers, or robot drivers.

Default invocation validates the fixture manifest and selected world hashes, then prints a plan. It does not create the output directory, import ROS/Gazebo, or start children. Actual execution requires `--execute`. Existing output directories are refused. Every case gets a fresh random Gazebo partition, independent owned process sessions, and an initial ROS-domain emptiness probe. Domain 77 is the draft default; the live experiment uses domain 73. Domain checking is cooperative, not an atomic exclusivity lock.

From the checkout, a **plan-only** example:

```bash
/usr/bin/python3 -B outputs/setup/red-calibration-runner-draft/runner.py \
  --output outputs/red-calibration/example-new \
  --case 01_blank --case 02_center_0400mm
```

Use `--all` instead of `--case` to select all 12 manifest entries. Default manifest is `outputs/setup/red-calibration-draft/integrated-example-v1/manifest.json`. The runner never opens `offline_truth` files. The original manifest is hashed for provenance, but labels, target counts, geometry checks and expected detections are not passed to capture.

For a **future explicitly authorized run**, use the environment wrapper to load F model dependencies followed by C's current single-spawn bringup. The wrapper compares installed launch/helpers with current source and starts only the runner. Omitting `--execute` still prints a plan:

```bash
bash outputs/setup/red-calibration-runner-draft/env.sh \
  /mnt/f/study/Personal_Plan/LIMO_Map_Nav_FromSimToRel \
  --output outputs/red-calibration/future-blank-new --case 01_blank \
  --case-wall 300 --batch-wall 7200 --execute
```

Per-case sequence: isolation probe → single-spawn simulator and sensor integrity probe → native model-ID snapshot → first six synchronized RGB-D pairs → second native ID snapshot → owned cleanup. Capture receives only case ID, output, fixed six-pair/time/byte budgets, registration assertion and odom/base frame names. No outcome-based retry, frame replacement, or automatic GLX→EGL retry occurs; `--egl` is an explicit separate-run choice. Input rejections remain in the six selected pairs and may make capture fail. Empty detections do not by themselves mean capture failed or that no target exists. Truth scoring is separate and never performed by this runner.

The case active deadline defaults to 300 wall seconds, after which cleanup starts. At most six owned groups each reserve 20 s INT + 5 s TERM + 3 s KILL, 168 s in total. The 7200 s batch wall budget includes prior cases and reserves that cleanup allowance before allowing the current case to run. Clock checks use monotonic wall time, independently of ROS clock. Scheduling or blocked OS I/O can still overrun these cooperative bounds; any observed batch overrun is reported incomplete. There is no claim of an OS-enforced hard lifetime bound.

Ownership uses the existing `record_bounded` `/proc` UID/session/start-ticks/environment-token checks and pidfd signaling. Commands cannot execute until a newly created session's owner record is saved and its pipe gate is released. Only these owned groups are stopped. Missing ownership or incomplete final scans cannot be called empty; no subsequent case starts unless all prior owned groups are confirmed empty. Any failed case also stops the batch without a retry. Final per-case reports retain commands, source hashes, child exit codes, signal escalation and remaining-members checks. Forced killing prevents a `captured` result.

`capture_passed` is a sensor/data-validity result, not detector recall, calibrated range, class correctness, or coverage. Native snapshots verify only model count/ID, **not native pose or physical stationarity**. `stationarity_verified=false` remains explicit. Exact per-sample odom/base TF is ROS-layer evidence only. Nominal camera world z=0.18 from the generator is not a measured settled height; the model can settle below zero, and map/odom TF heights have different origins. Do not compare map→camera z directly with world-truth z or score geometry until settled native pose and frame conventions are separately established.

Pure tests, with no ROS imports or child processes:

```bash
/usr/bin/python3 -B -m unittest discover \
  -s outputs/setup/red-calibration-runner-draft -p 'test_*.py' -v
bash -n outputs/setup/red-calibration-runner-draft/env.sh
```

Runtime ownership helper behavior is borrowed from its existing dummy-process regressions; these new tests cover planning, truth separation, budgets, refusal/stop policies and no-execute behavior. A real sensor-only one-case trial and inspection of raw images, CameraInfo, exact TF and cleanup evidence are still required before a twelve-case batch.
