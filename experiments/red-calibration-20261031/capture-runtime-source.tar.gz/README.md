# Red surrogate sensor capture draft

This draft captures a bounded set of sensor observations and independently runs the current checkout's red RGB-D core. It does not read fixture worlds, offline truth, native model poses/counts, online detection topics, mission data, map epochs or target labels. `case-id` is only an opaque output label.

**Verified so far:** 36 offline tests passed in 5.116 s, exit 0. Tests use synthetic image arrays, fake TF lookups and owned dummy subprocesses. They explicitly verify that `rclpy` was not imported. No real capture, ROS/Gazebo node or service was started for this work, and run20/domain 73 was not contacted. The ROS subscription path remains untested in a live environment.

## Future runtime invocation

Only after the experiment owner has launched and verified a separate stationary sensor-only fixture:

```bash
source /opt/ros/jazzy/setup.bash
python3 -B /absolute/repository/outputs/setup/red-capture-draft/capture_red_samples.py \
  --execute --registered-depth \
  --case-id 02_center_0400mm \
  --pairs 6 --timeout 60 --pair-wait 2 \
  --output /absolute/new/capture-directory
```

This command was **not run** during preparation. The owner must retain the relevant `ROS_DOMAIN_ID` and own the existing simulator. The tool neither starts nor stops it. It creates no publisher for motion, goals, observations or mission evidence. It does not import the online perception node. It disables rosout and parameter services on its capture node and enables simulation time.

The tool does not prove physical stationarity or braking. The fixture experiment supplies that condition. A separate owner must enforce a hard process deadline if native code or file I/O blocks. The tool's wall deadline bounds the sampling loop; sampling completion also checks elapsed collection and local processing time before cleanup. Native cleanup duration is recorded separately and cannot retroactively change sampling completion. Cleanup may block and needs the owner's hard deadline.

The source checkout must be present: the helper finds `src/limo_maze_perception`, imports that exact core/evidence path rather than an installed overlay, and retains source hashes and copies. Moving these helpers to repository `scripts/` later preserves this discovery behavior. Arbitrary installed locations outside a checkout are intentionally unsupported by this draft.

## Inputs and selection

- `/clock` establishes a positive capture barrier. Acquisition stamps must be integer nanoseconds strictly newer than that barrier; a backward clock makes the capture fail.
- The first N advancing, fresh, exactly synchronized `/camera/color/image_raw` and `/camera/depth/image_raw` pairs are selected in **callback-time pair-availability order**. Stamps are sorted only among pairs available together in one callback. The tool does not wait for an older unmatched image; a pair that becomes ready later at or below the last selected stamp is rejected as `nonadvancing_pair`. This is not a claim to capture the globally earliest N sensor acquisition stamps. A selected pair that later fails is retained; collection does not keep searching until N successful detections.
- Both `/camera/color/camera_info` and `/camera/depth/camera_info` must match the selected acquisition stamp, dimensions, frame and calibration. Metadata validation reuses the production evidence validator with zero timing slop. The explicit `--registered-depth` assertion documents the simulator convention; matching metadata alone does not experimentally establish depth registration.
- The current production `DetectorConfig()` defaults are used and recorded in full. These match the current online node defaults: `min_area_pixels=30`, `min_depth_pixels=8`, depth cutoffs 0.15–6 m. Those cutoffs are algorithm settings, **not a measured effective range**. This tool does not read a running detector's possibly overridden parameters.
- For each valid image input, the current `process_red_frame` is called once. It retains detection positions in the optical frame, confidence, frame depth quality, candidate counts and every core rejection counter. The red-mask PNG is recomputed from the same production mask function solely for review.
- TF lookups request the exact nonzero integer acquisition time for `odom→base_footprint`, `base_footprint→camera_optical_frame` and `odom→camera_optical_frame`. Frames may be changed using the two explicit frame options. Dynamic lookup results must retain the requested stamp; the camera mounting lookup alone permits stamp zero for static TF. No latest-time lookup is substituted.
- Metadata/core errors and TF errors remain separate. Missing TF does not hide an otherwise completed image detection. Empty output is recorded as `no_red_candidates` or `all_candidates_rejected`; neither is treated as proof that no target exists.

Caches are bounded. Same-stamp identical messages do not advance the sample count; conflicting duplicate payloads are recorded and fail the overall capture. Ordinary signature history retains at most 64 stamps per topic. Separately, the first signature for every **selected** acquisition stamp is pinned until sampling ends, across all four image/calibration topics: at most 32 stamps per topic, including samples already written. CameraInfo signatures first arriving after pair selection are pinned on receipt. Thus 65 newer messages cannot erase the duplicate-conflict check for a selected sample.

`selected_sample_conflicts` preserves the sample sequence, integer stamp, committed artifact path (if any), topic, retained/conflicting signatures and conflict count independently of the 40-entry diagnostic event cap. A same-stamp conflict received after the sample was saved makes the final integrity verdict fail, while that sample's original files remain unchanged. `all_samples_valid_when_saved` records the write-time result; `all_samples_valid` also accounts for these selected-sample conflicts at sampling end. Unselected conflict details are retained only while the stamp remains in bounded signature history; their cumulative conflict count remains sticky and still fails the capture after detail eviction. These checks cover callbacks actually received before sampling freezes, not arbitrarily late messages after the finite capture ends.

Oversized messages are dropped before retention and counted, with no successful whole-stream claim. Unmatched exact stamps may expire or be evicted; summary counters make these losses explicit.

## Artifacts

The output directory must not exist. Each write is exclusive and completes a file `flush()` and `fsync()` before it is listed as saved. A default 256 MiB byte budget, including two reserved 128 KiB report slots, stops growth rather than replacing earlier artifacts. This supports retention through process termination; it is not a tested guarantee against host or storage power loss.

`manifest.json` stores settings, session ID, topic list, source paths/hashes and library versions. `source/` retains the exact files read for the current detector core, evidence logic, node defaults and both capture helpers. Source stability is checked at sampling end, before native cleanup.

Each `sample_NNN/` includes:

- `sample.json`: integer acquisition stamps, original image metadata/hashes, both full CameraInfo calibration records and IDs, explicit TF requests/returned transforms, detections, quality statistics, valid/rejected reasons, file hashes and capture clock context.
- `rgb.data` and `depth.data`: original ROS `Image.data` bytes, including row padding and byte order, whenever within the input bound. These preserve evidence even when calibration or decoding is rejected.
- For decodable eligible inputs, lossless `rgb.png`, native-unit `depth_raw.npy`, metre-unit `depth_m.npy`, and `red_mask.png`. RGB/BGR, 32FC1 metres, 16UC1 millimetres, row padding and endian conversion are supported. NaN/Infinity depth samples remain in the arrays and raw bytes; no invalid values are silently filled.

Some derived images may be absent for a rejected input; its raw bytes and reason remain authoritative. JSON never contains NaN/Infinity. Invalid calibration fields are represented as null and rejected, not used for projection.

Before listener, node or context cleanup, `raw-checkpoint.json` records sampling outcome, every committed sample, pending sample IDs, saved artifact names/hashes and callback/drop diagnostics. The checkpoint is immutable and flushed/fsynced before the first native cleanup call. Its `cleanup_complete=false`, `partial=true` and `passed=false` prevent it from being mistaken for successful cleanup. If `summary.json` is absent after a native abort or owner hard kill during cleanup, use this checkpoint and treat cleanup completion as unknown. Files from a partially failed sample write may be listed as saved artifacts, but that sample is not promoted to the committed sample list.

After cleanup returns, `summary.json` separately records `sampling_complete` (`collection_complete` is an alias), `sampling_passed`, `cleanup_complete`, individual cleanup returns/errors, `all_samples_valid`, `source_unchanged`, the checkpoint hash and any stop signal. `partial` describes incomplete sampling/cleanup or interruption; a fully collected invalid frame can instead be a complete rejected capture. `passed` requires completed valid sampling, completed cleanup and no errors/interruption. A blank frame can pass with zero detections; a red panel may be detected by this color-only algorithm. Dataset truth comparison, false-positive/false-negative analysis and measured validity ranges are later offline tasks.

SIGINT and SIGTERM set a stop flag; repeated signals do not directly destroy native state. The ROS context uses `SignalHandlerOptions.NO`, so its default signal handling cannot race the checkpoint. The loop stops selecting new inputs, saves pending selected pairs with an interruption reason and without further TF queries, persists the checkpoint, then attempts cleanup. Previous signal handlers are restored afterward. The owner should allow a bounded grace interval before a hard kill; a kill before checkpoint creation, or blocked I/O, can still prevent a complete checkpoint. A Python cleanup exception is recorded and remaining cleanup steps are attempted. An actual native abort cannot be caught.

The summary explicitly makes no effective-range or search-coverage claim. Six adjacent observations in a fixture are repeated measurements, not six independent scenes. Each of the 12 fixtures needs its own new output directory and controlled experiment record.

## Offline validation

```bash
python3 -B -m unittest discover \
  -s /absolute/repository/outputs/setup/red-capture-draft -p 'test_*.py' -v
```

The tests exercise normal/blank/red-with-invalid-depth frames, one-nanosecond mismatch, stale/mismatched calibration, distorted ROI, bad buffers, missing/wrong-time/invalid TF, byte order and padding, unchanged production projections, pair-availability selection including a late older pair, duplicate conflicts, clock reset, bounded caches, exclusive output/byte limits, saved PNG/depth/hash round trips, exact lookup arguments and absence of ROS imports. Selected-signature regressions cover 65-message eviction for every image/calibration topic, the maximum 32 pins per topic, bounded unselected-conflict history with sticky failure, and a late conflict after sample write and event-log truncation that fails the summary without changing original bytes. Lifecycle tests check fsync before cleanup, separate sampling/cleanup timing, Python cleanup errors, actual SIGINT/SIGTERM in dummy subprocesses, handler restoration, and an uncatchable `os._exit(86)` from a fake native-cleanup callback. The latter proves the checkpoint survives this simulated abrupt process exit; it is not a live ROS native-crash validation. Tests do not establish actual rendered visibility, sensor frequency, physical stationarity, registration accuracy, detector recall or any of the 12 fixture outcomes.
